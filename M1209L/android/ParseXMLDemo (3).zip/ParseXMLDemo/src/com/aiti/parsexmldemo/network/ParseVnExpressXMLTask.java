package com.aiti.parsexmldemo.network;

import android.os.AsyncTask;

public class ParseVnExpressXMLTask extends AsyncTask {

	@Override
	protected Object doInBackground(Object... params) {
		// TODO Auto-generated method stub
		return null;
	}

}
