package com.aiti.parsexmldemo.network;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

public class GetBitmapFromUrlTask extends AsyncTask<String, Void, Bitmap> {

	@Override
	protected Bitmap doInBackground(String... arg0) {
		Bitmap image;
		try {
			URL url = new URL(arg0[0]);
			InputStream is = url.openConnection().getInputStream();
			image = BitmapFactory.decodeStream(is);
			return image;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
