package com.demo.music.db;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MusicDatabaseHelper extends SQLiteOpenHelper {

	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "MusicData";
	private static final String MUSIC_TABLE = "musics";

	private String CREATE_MUSICS_TABLE = "CREATE TABLE musics ( \"id\" INTEGER PRIMARY KEY, \"url\" VARCHAR(100))";

	public MusicDatabaseHelper(Context context, String name,
			CursorFactory factory, int version) {
		super(context, name, factory, version);
	}

	public MusicDatabaseHelper(Context context) {
		this(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_MUSICS_TABLE);
		ContentValues values = new ContentValues();
		values.put(
				"url",
				"http://data.chiasenhac.com/downloads/1030/5/1029398-d259cceb/128/Co%20Hang%20Xom%20-%20Quang%20Le%20%5BMP3%20128kbps%5D.mp3");
		db.insert(MUSIC_TABLE, null, values);
	}

	public ArrayList<String> getAllUrls() {
		ArrayList<String> urls = new ArrayList<String>();
		SQLiteDatabase database = getReadableDatabase();
		Cursor cursor = database.query(MUSIC_TABLE,
				new String[] { "id", "url" }, null, null, null, null, null);
		while (cursor.moveToNext()) {
			String url = cursor.getString(1);
			urls.add(url);
		}
		cursor.close();
		database.close();
		return urls;
	}

	public long insertNewUrl(String url) {
		SQLiteDatabase database = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("url", url);
		long id = database.insert(MUSIC_TABLE, null, values);
		database.close();
		return id;
	}

	public int updateUrl(long id, String url) {
		SQLiteDatabase database = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("url", url);
		int count = database.update(MUSIC_TABLE, values, "id = ?",
				new String[] { "" + id });
		return count;
	}

	public boolean deleteUrl(long id) {
		SQLiteDatabase database = getWritableDatabase();
		int count = database.delete(MUSIC_TABLE, "id = ?", new String[] { ""
				+ id });
		return count > 0 ? true : false;
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}

}
