package com.example.demofragment.ui.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Toast;

import com.example.demofragment.R;
import com.example.demofragment.adapter.AdapterNews;

public class FragmentDanTri extends Fragment implements OnCheckedChangeListener {
	private static final String STATE_CHECK_BOX = "STATE CHECK BOX";
	private Button button;
	private String url;
	private CheckBox chkTest;
	private boolean isState;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_dantri, null);
		button = (Button) view.findViewById(R.id.button1);
		url = getArguments().getString(AdapterNews.URL);
		chkTest = (CheckBox) view.findViewById(R.id.checkBox1);
		if (null != savedInstanceState)
			isState = savedInstanceState.getBoolean(STATE_CHECK_BOX);
		chkTest.setChecked(isState);
		button.setText(url);
		chkTest.setOnCheckedChangeListener(this);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		outState.putBoolean(STATE_CHECK_BOX, isState);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	public void onDetach() {
		// TODO Auto-generated method stub
		super.onDetach();
		Toast.makeText(getActivity().getApplicationContext(),
				"Detached " + url, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
		super.onDestroyView();
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		isState = isChecked;

	}

}
