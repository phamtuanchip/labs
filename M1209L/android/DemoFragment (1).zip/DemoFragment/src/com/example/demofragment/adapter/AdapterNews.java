package com.example.demofragment.adapter;

import com.example.demofragment.ui.fragment.FragmentDanTri;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class AdapterNews extends FragmentStatePagerAdapter {

	public static final String URL = "URL";

	public AdapterNews(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		String str;
		switch (position) {
		case 0:
			str = "Dan Tri";
			break;
		case 1:
			str = "VnExpress";
			break;
		case 2:
			str = "24h";
			break;
		case 3:
			str = "linkhay";
			break;
		default:
			str = "Vietnamnet";
			break;
		}
		Fragment fragment = new FragmentDanTri();
		Bundle args = new Bundle();
		args.putString(URL, str);
		fragment.setArguments(args);
		return fragment;
	}

	@Override
	public int getCount() {
		return 5;
	}

}
