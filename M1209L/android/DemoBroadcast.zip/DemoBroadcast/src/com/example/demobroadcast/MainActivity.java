package com.example.demobroadcast;

import android.app.Activity;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import com.example.demobroadcast.receiver.BroadcastCalling;

public class MainActivity extends Activity {
	private String TAG = "MainActivity";

	private BroadcastCalling calling = new BroadcastCalling() {

		@Override
		public void onIncommingCall() {
			Log.e(TAG, "Incomming call");
		}

		@Override
		public void onIdle() {
			Log.e(TAG, "Idle call");
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		IntentFilter filter = new IntentFilter(
				"android.intent.action.PHONE_STATE");
		registerReceiver(calling, filter);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(calling);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
