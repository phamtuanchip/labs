package com.aiti.parsexmldemo.network;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;

import com.aiti.parsexmldemo.view.MyControllImage;

public class GetBitmapFromUrlTask extends AsyncTask<String, Void, Bitmap> {

	@Override
	protected Bitmap doInBackground(String... arg0) {
		try {
			String strUrl = arg0[0];
			Bitmap bitmap = MyControllImage.getInstance().getBitmap(strUrl);
			if (null == bitmap) {
				URL url = new URL(arg0[0]);
				InputStream is = url.openConnection().getInputStream();
				String fileName = MyControllImage.optimizePath(strUrl);
				writeToSDCard(fileName, is);
				MyControllImage.getInstance().saveToCache(strUrl);
				bitmap = MyControllImage.getInstance().getBitmap(strUrl);
			}
			return bitmap;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Ghi anh vua download ve vao trong Sdcard
	 * 
	 * @param fileName
	 *            : Ten file (Chinh la duong dan URL da duoc chuan hoa)
	 * @param input
	 *            : Inputstream
	 * @throws IOException
	 */
	private void writeToSDCard(String fileName, InputStream input)
			throws IOException {
		String path = Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/DanTri/";
		File folder = new File(path);
		if (!folder.exists()) {
			folder.mkdir();
		}
		path = path + fileName + ".jpg";
		File file = new File(path);
		file.createNewFile();
		final OutputStream output = new FileOutputStream(file);
		try {
			try {
				final byte[] buffer = new byte[1024];
				int read;

				while ((read = input.read(buffer)) != -1)
					output.write(buffer, 0, read);

				output.flush();
			} finally {
				output.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			input.close();
		}
	}
}
