package com.aiti.parsexmldemo.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.aiti.parsexmldemo.network.GetBitmapFromUrlTask;

public class MyImageView extends ImageView {

	private String url;
	private GetBitmapFromUrlTask task;

	public MyImageView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public MyImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MyImageView(Context context) {
		super(context);
	}

	public void setImageUrl(String url) {
		// SmartImageView.
		// Universal ImageView.
		if (task != null) {
			task.cancel(true);
		}
		this.url = url;
		task = new GetBitmapFromUrlTask() {
			@Override
			protected void onPostExecute(Bitmap result) {
				setImageBitmap(result);
			}
		};
		task.execute(this.url);
//		ExecutorService executors = Executors.newCachedThreadPool();
	}

}
