package com.aiti.parsexmldemo.parse;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.aiti.parsexmldemo.data.NewsItem;

public class DataHandler extends DefaultHandler {
	private static final String TAG = "PARSE";
	private ArrayList<NewsItem> result;
	private boolean _inItemTag;
	private NewsItem newsItem;
	private boolean _inLinkTag;
	private boolean _inTitleTag;
	private boolean _inDescTag;
	private boolean _inPubDateTag;
	private int mCount = 0;

	public DataHandler() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<NewsItem> getData() {
		return result;
	}

	/*
	 * This gets called when the xml document is first opened
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		result = new ArrayList<NewsItem>();
	}

	/**
	 * Called when it's finished handling the document
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {

	}

	/**
	 * This gets called at the start of an element. Here we're also setting the
	 * booleans to true if it's at that specific tag. (so we know where we are)
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @param atts
	 * @throws SAXException
	 */
	@Override
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {

		if (localName.equals("item")) {
			_inItemTag = true;
			newsItem = new NewsItem();
		} else if (localName.equals("link") && _inItemTag) {
			_inLinkTag = true;
		} else if (localName.equals("title") && _inItemTag) {
			_inTitleTag = true;
		} else if (localName.equals("description") && _inItemTag) {
			_inDescTag = true;
		} else if (localName.equals("pubDate") && _inItemTag) {
			_inPubDateTag = true;
		}

		// else if (localName.equals("title")) {
		// _inArea = true;
		// }
	}

	/**
	 * Called at the end of the element. Setting the booleans to false, so we
	 * know that we've just left that tag.
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @throws SAXException
	 */
	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		Log.v("endElement", localName);

		if (localName.equals("title") && _inTitleTag) {
			_inTitleTag = false;
		} else if (localName.equals("link") && _inLinkTag) {
			_inLinkTag = false;
		} else if (localName.equals("description") && _inDescTag) {
			_inDescTag = false;
		} else if (localName.equals("pubDate") && _inPubDateTag) {
			_inPubDateTag = false;
		} else if (localName.equals("item")) {
			result.add(newsItem);
			_inItemTag = false;
		}

		// else if (localName.equals("area")) {
		// _inArea = false;
		// }
	}

	/**
	 * Calling when we're within an element. Here we're checking to see if there
	 * is any content in the tags that we're interested in and populating it in
	 * the Config object.
	 * 
	 * @param ch
	 * @param start
	 * @param length
	 */
	@Override
	public void characters(char ch[], int start, int length) {
		String chars = new String(ch, start, length);
		chars = chars.trim();

		if (_inTitleTag) {
			newsItem.setTitle(chars);
		} else if (_inLinkTag) {
			newsItem.setLink(chars);
		} else if (_inDescTag) {
			String url = getUrlImage(chars);
			newsItem.setImageUrl(url);
			String desc = optimizerDesc(chars);
			newsItem.setDesc(desc);
		} else if (_inPubDateTag) {
			newsItem.setPubDate(chars);
		}
	}

	private String getUrlImage(String content) {
		String result = null;
		Pattern pattern = Pattern.compile("(src=\"http.*\\.jpg)");
		Matcher matcher = pattern.matcher(content);
		while (matcher.find()) {
			int start = matcher.start();
			int end = matcher.end();
			result = content.substring(start+5, end);
			break;
		}
		return result;
	}

	private String optimizerDesc(String content) {
		//(<\/a>.*<br>) < Sua lai theo cai nay
		String result = "";
		int start=0;
		Pattern pattern = Pattern.compile("(<\\/a>)");
//		Pattern pattern2 = Pattern.compile("(<\\/a>.*<br>) ");
		Matcher matcher = pattern.matcher(content);
		int count = 0;
		while (matcher.find()) {
			if (count == 0) {
				start = matcher.start();
				break;
			} else {
				count++;
			}
		}
		Log.e(TAG, "Count = " + mCount);
		mCount++;
		String test = content.substring(start, content.length());
		int end = test.indexOf("<a");
		if (end == -1) {
			end = test.length();
		}
		test = test.substring(4, end);
		test = test.replaceAll("<br>", "");
		// content.split(, limit)
		return test;
	}
}
