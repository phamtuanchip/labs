package com.aiti.parsexmldemo;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;

import com.aiti.parsexmldemo.adapter.AdapterDanTri;
import com.aiti.parsexmldemo.data.NewsItem;
import com.aiti.parsexmldemo.network.ParseDanTriXMLTask;

public class MainActivity extends Activity implements OnClickListener {
	private ListView listDantri;
	private AdapterDanTri adapterDanTri;
	private Button btnReadXml;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnReadXml = (Button) findViewById(R.id.btnReadXml);
		listDantri = (ListView) findViewById(R.id.list_bongda_dantri);
		adapterDanTri = new AdapterDanTri(getApplicationContext(),
				new ArrayList<NewsItem>());
		listDantri.setAdapter(adapterDanTri);
		btnReadXml.setOnClickListener(this);

	}

	@Override
	public void onClick(View arg0) {
		ParseDanTriXMLTask danTriXMLTask = new ParseDanTriXMLTask() {
			// /Running on main thread
			// Update listview
			protected void onPostExecute(ArrayList<NewsItem> result) {
				for (NewsItem item : result) {
					adapterDanTri.add(item);
				}
				adapterDanTri.notifyDataSetChanged();
			};

			@Override
			protected void onProgressUpdate(Integer... values) {
				super.onProgressUpdate(values);
			}
		};
		danTriXMLTask.execute("http://dantri.com.vn/bong-da-quoc-te.rss");
	}
}
