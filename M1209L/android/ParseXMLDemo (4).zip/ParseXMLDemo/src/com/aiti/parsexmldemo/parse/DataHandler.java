package com.aiti.parsexmldemo.parse;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.aiti.parsexmldemo.data.NewsItem;

public class DataHandler extends DefaultHandler {
	private ArrayList<NewsItem> result;
	private boolean _inItemTag;
	private NewsItem newsItem;

	public DataHandler() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<NewsItem> getData() {
		return result;
	}

	/*
	 * This gets called when the xml document is first opened
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		result = new ArrayList<NewsItem>();
	}

	/**
	 * Called when it's finished handling the document
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {

	}

	/**
	 * This gets called at the start of an element. Here we're also setting the
	 * booleans to true if it's at that specific tag. (so we know where we are)
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @param atts
	 * @throws SAXException
	 */
	@Override
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {

		if (localName.equals("item")) {
			_inItemTag = true;
			newsItem = new NewsItem();
		}

		// else if (localName.equals("title")) {
		// _inArea = true;
		// }
	}

	/**
	 * Called at the end of the element. Setting the booleans to false, so we
	 * know that we've just left that tag.
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @throws SAXException
	 */
	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		Log.v("endElement", localName);

		if (localName.equals("title") && _inItemTag) {
			_inItemTag = false;
			result.add(newsItem);

		}
		// else if (localName.equals("area")) {
		// _inArea = false;
		// }
	}

	/**
	 * Calling when we're within an element. Here we're checking to see if there
	 * is any content in the tags that we're interested in and populating it in
	 * the Config object.
	 * 
	 * @param ch
	 * @param start
	 * @param length
	 */
	@Override
	public void characters(char ch[], int start, int length) {
		String chars = new String(ch, start, length);
		chars = chars.trim();

		if (_inItemTag) {
			// _data.section = chars;
			newsItem.setTitle(chars);

		}

		// else if (_inArea) {
		// _data.area = chars;
		// }
	}

}
