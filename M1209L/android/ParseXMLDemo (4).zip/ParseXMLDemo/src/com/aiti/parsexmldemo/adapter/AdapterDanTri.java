package com.aiti.parsexmldemo.adapter;

import java.util.List;

import com.aiti.parsexmldemo.R;
import com.aiti.parsexmldemo.data.NewsItem;
import com.aiti.parsexmldemo.view.MyImageView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class AdapterDanTri extends ArrayAdapter<NewsItem> {
	private LayoutInflater inflater;

	public AdapterDanTri(Context context, List<NewsItem> objects) {
		super(context, -1, objects);
		inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		NewsItem item = getItem(position);
		ViewHolder holder;
		if (null == convertView) {
			convertView = inflater.inflate(R.layout.item_dantri, null);
			holder = new ViewHolder();
			holder.txtDesc = (TextView) convertView.findViewById(R.id.txtDesc);
			holder.txtTitle = (TextView) convertView
					.findViewById(R.id.txtTitle);
			holder.txtPubDate = (TextView) convertView
					.findViewById(R.id.txtPubDate);
			holder.imgItem = (MyImageView) convertView
					.findViewById(R.id.imgItem);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.txtTitle.setText(item.getTitle());
		holder.txtDesc.setText(item.getDesc());
		holder.txtPubDate.setText(item.getPubDate());
		holder.imgItem.setImageUrl(item.getImageUrl());
		return convertView;
	}

	private class ViewHolder {
		private TextView txtTitle;
		private TextView txtDesc;
		private MyImageView imgItem;
		private TextView txtPubDate;
	}
}
