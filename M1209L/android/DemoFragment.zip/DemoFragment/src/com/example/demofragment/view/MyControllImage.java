package com.example.demofragment.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

public class MyControllImage {
	ArrayList<String> cache;
	private static MyControllImage instance;

	// Memory
	// Storage
	// Get URL;
	public synchronized static MyControllImage getInstance() {
		if (null == instance) {
			instance = new MyControllImage();
		}
		return instance;
	}

	public MyControllImage() {
		cache = new ArrayList<String>();
	}

	/**
	 * Kiem tra xem url nay da ton tai trong Sdcard chua. Neu da ton tai thi tra
	 * ve bitmap
	 * 
	 * @param url
	 * @return Tra va Bitmap hoac NULL
	 */
	public Bitmap getBitmap(String url) {
		// neu cache ton tai url > tuc la da download ve sdcard
		if (cache.contains(url)) {
			try {
				return getBitmapFromSDCard(url);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return null;
		}
	}

	/**
	 * Lay bitmap tu sdcard
	 * 
	 * @param url
	 *            : Duong dan url
	 * @return : Bitmap
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private Bitmap getBitmapFromSDCard(String url) throws IOException,
			FileNotFoundException {
		String path = Environment.getExternalStorageDirectory()
				.getAbsolutePath() + "/DanTri/" + optimizePath(url) + ".jpg";
		File file = new File(path);
		FileInputStream fis = new FileInputStream(file);
		Bitmap bitmap = BitmapFactory.decodeStream(fis);
		fis.close();
		return bitmap;
	}

	/**
	 * SUa toan bo cac ky tu : . thanh dau - (Vi ten file khong cho phep ky tu
	 * la)
	 * 
	 * @param url
	 * @return Chuoi String chuan co the dat duoc ten file
	 */
	public static String optimizePath(String url) {
		url = url.replaceAll("([/:\\.])", "-");
		return url;
	}

	/**
	 * Dang ky voi quan ly la da co url nay trong sdcard
	 * 
	 * @param strUrl
	 */
	public void saveToCache(String strUrl) {
		cache.add(strUrl);
	}
}
