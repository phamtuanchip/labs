package com.example.demofragment.data;

import java.io.Serializable;

public class NewsItem implements Serializable {
	private String title;
	private String desc;
	private String imageUrl;
	private String pubDate;
	private String mainUrl;
	private String link;

	public NewsItem() {
		// TODO Auto-generated constructor stub
		title = "";
		desc = "";
		imageUrl="";
		pubDate = "";
		mainUrl = "";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 5759334248399632998L;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getPubDate() {
		return pubDate;
	}

	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}

	public String getMainUrl() {
		return mainUrl;
	}

	public void setMainUrl(String mainUrl) {
		this.mainUrl = mainUrl;
	}

	public void setLink(String link) {
		// TODO Auto-generated method stub
			this.link = link;
	}

}
