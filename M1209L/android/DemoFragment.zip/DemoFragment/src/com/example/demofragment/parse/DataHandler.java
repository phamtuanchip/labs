package com.example.demofragment.parse;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

import com.example.demofragment.data.NewsItem;

public abstract class DataHandler extends DefaultHandler {
	private static final String TAG = "PARSE";
	private ArrayList<NewsItem> result;
	private boolean _inItemTag;
	private NewsItem newsItem;
	private boolean _inLinkTag;
	private boolean _inTitleTag;
	private boolean _inDescTag;
	private boolean _inPubDateTag;
	private int mCount = 0;
	private final StringBuilder mStringBuilder = new StringBuilder();

	public DataHandler() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<NewsItem> getData() {
		return result;
	}

	/*
	 * This gets called when the xml document is first opened
	 * 
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException {
		result = new ArrayList<NewsItem>();
	}

	/**
	 * Called when it's finished handling the document
	 * 
	 * @throws SAXException
	 */
	@Override
	public void endDocument() throws SAXException {

	}

	/**
	 * This gets called at the start of an element. Here we're also setting the
	 * booleans to true if it's at that specific tag. (so we know where we are)
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @param atts
	 * @throws SAXException
	 */
	@Override
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {

		if (localName.equals("item")) {
			_inItemTag = true;
			newsItem = new NewsItem();
		} else if (localName.equals("link") && _inItemTag) {
			_inLinkTag = true;
			mStringBuilder.setLength(0);
		} else if (localName.equals("title") && _inItemTag) {
			_inTitleTag = true;
			mStringBuilder.setLength(0);
		} else if (localName.equals("description") && _inItemTag) {
			_inDescTag = true;
			mStringBuilder.setLength(0);
		} else if (localName.equals("pubDate") && _inItemTag) {
			_inPubDateTag = true;
			mStringBuilder.setLength(0);
		}

		// else if (localName.equals("title")) {
		// _inArea = true;
		// }
	}

	/**
	 * Called at the end of the element. Setting the booleans to false, so we
	 * know that we've just left that tag.
	 * 
	 * @param namespaceURI
	 * @param localName
	 * @param qName
	 * @throws SAXException
	 */
	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		Log.v("endElement", localName);

		if (localName.equals("title") && _inTitleTag) {
			_inTitleTag = false;
			newsItem.setTitle(mStringBuilder.toString().trim());
		} else if (localName.equals("link") && _inLinkTag) {
			_inLinkTag = false;
			newsItem.setLink(mStringBuilder.toString().trim());
		} else if (localName.equals("description") && _inDescTag) {
			_inDescTag = false;
			String content = mStringBuilder.toString().trim();
			String url = getUrlImage(content);
			newsItem.setImageUrl(url);
			String desc = getDesc(content);
			newsItem.setDesc(desc);
		} else if (localName.equals("pubDate") && _inPubDateTag) {
			_inPubDateTag = false;
			newsItem.setPubDate(mStringBuilder.toString().trim());
		} else if (localName.equals("item")) {
			result.add(newsItem);
			_inItemTag = false;
		}

		// else if (localName.equals("area")) {
		// _inArea = false;
		// }
	}

	/**
	 * Calling when we're within an element. Here we're checking to see if there
	 * is any content in the tags that we're interested in and populating it in
	 * the Config object.
	 * 
	 * @param ch
	 * @param start
	 * @param length
	 */
	@Override
	public void characters(char ch[], int start, int length) {

		if (_inTitleTag) {
			mStringBuilder.append(ch, start, length);

		} else if (_inLinkTag) {
			mStringBuilder.append(ch, start, length);

		} else if (_inDescTag) {
			mStringBuilder.append(ch, start, length);

		} else if (_inPubDateTag) {
			mStringBuilder.append(ch, start, length);

		}
	}

	protected abstract String getUrlImage(String content);

	protected abstract String getDesc(String content);
}
