package com.example.demofragment.parse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DanTriHandler extends DataHandler {
	@Override
	protected String getDesc(String content) {
		int start = 0;
		Pattern pattern = Pattern.compile("(<\\/a>)");
		Matcher matcher = pattern.matcher(content);
		int count = 0;
		while (matcher.find()) {
			if (count == 0) {
				start = matcher.start();
				break;
			} else {
				count++;
			}
		}
		String test = content.substring(start, content.length());
		int end = test.indexOf("<a");
		if (end == -1) {
			end = test.length();
		}
		test = test.substring(4, end);
		test = test.replaceAll("<br>", "");
		// content.split(, limit)
		return test;
	}

	protected String getUrlImage(String content) {
		String result = null;
		Pattern pattern = Pattern.compile("(src=\"http.*\\.jpg)");
		Matcher matcher = pattern.matcher(content);
		while (matcher.find()) {
			int start = matcher.start();
			int end = matcher.end();
			result = content.substring(start + 5, end);
			break;
		}
		return result;
	};
}
