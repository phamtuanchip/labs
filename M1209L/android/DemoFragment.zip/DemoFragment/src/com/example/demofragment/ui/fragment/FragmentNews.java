package com.example.demofragment.ui.fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.Toast;

import com.example.demofragment.R;
import com.example.demofragment.adapter.AdapterDanTri;
import com.example.demofragment.adapter.AdapterNews;
import com.example.demofragment.data.NewsItem;
import com.example.demofragment.network.ParseDanTriXMLTask;
import com.example.demofragment.network.ParseVnExpressXMLTask;

public class FragmentNews extends Fragment implements
		OnCheckedChangeListener, OnClickListener {
	private static final String STATE_CHECK_BOX = "STATE CHECK BOX";
	private static final String LIST_NEWS = "LIST NEWS";
	private Button button;
	private String url;
	private CheckBox chkTest;
	private boolean isState;
	private String title;
	private ListView mListNews;
	private AdapterDanTri adapterDanTri;
	private ArrayList<NewsItem> listNews;

	@SuppressWarnings("unchecked")
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_dantri, null);

		button = (Button) view.findViewById(R.id.button1);
		mListNews = (ListView) view.findViewById(R.id.list_news);
		adapterDanTri = new AdapterDanTri(
				getActivity().getApplicationContext(),
				new ArrayList<NewsItem>());

		url = getArguments().getString(AdapterNews.URL);

		title = getArguments().getString(AdapterNews.TITLE);
		chkTest = (CheckBox) view.findViewById(R.id.checkBox1);
		if (null != savedInstanceState) {
			isState = savedInstanceState.getBoolean(STATE_CHECK_BOX);
			listNews = (ArrayList<NewsItem>) savedInstanceState
					.getSerializable(LIST_NEWS);
			if (null != listNews && !listNews.isEmpty())
				adapterDanTri.addAll(listNews); // method chi chay >3.0
		}
		chkTest.setChecked(isState);
		button.setText(title);
		button.setOnClickListener(this);
		chkTest.setOnCheckedChangeListener(this);
		mListNews.setAdapter(adapterDanTri);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putSerializable(LIST_NEWS, listNews);
		outState.putBoolean(STATE_CHECK_BOX, isState);
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	public void onDetach() {
		// TODO Auto-generated method stub
		super.onDetach();
		Toast.makeText(getActivity().getApplicationContext(),
				"Detached " + url, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
		super.onDestroyView();
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		isState = isChecked;

	}

	@Override
	public void onClick(View arg0) {
		if (title.equals("Dan Tri")) {
			ParseDanTriXMLTask danTriXMLTask = new ParseDanTriXMLTask() {
				ProgressDialog progDailog;

				@Override
				protected void onPreExecute() {
					// TODO Auto-generated method stub
					super.onPreExecute();
					progDailog = ProgressDialog.show(getActivity(),
							"Getting xml from DanTri",
							"Give message like ....please wait....", true);

				}

				@Override
				protected void onPostExecute(ArrayList<NewsItem> result) {
					listNews = result;
					for (NewsItem item : result) {
						adapterDanTri.add(item);
					}
					progDailog.dismiss();
					adapterDanTri.notifyDataSetChanged();
				}
			};
			danTriXMLTask.execute(url);
		} else if (title.equals("VnExpress")) {
			ParseVnExpressXMLTask vnexpressTask = new ParseVnExpressXMLTask() {
				ProgressDialog progDailog;

				@Override
				protected void onPreExecute() {
					// TODO Auto-generated method stub
					super.onPreExecute();
					progDailog = ProgressDialog.show(getActivity(),
							"Getting xml from Vnexpress",
							"Give message like ....please wait....", true);

				}

				@Override
				protected void onPostExecute(ArrayList<NewsItem> result) {
					listNews = result;
					for (NewsItem item : result) {
						adapterDanTri.add(item);
					}
					progDailog.dismiss();
					adapterDanTri.notifyDataSetChanged();
				}
			};
			vnexpressTask.execute(url);
		}
	}

}
