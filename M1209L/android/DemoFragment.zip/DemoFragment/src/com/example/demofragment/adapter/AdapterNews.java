package com.example.demofragment.adapter;

import com.example.demofragment.ui.fragment.FragmentNews;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class AdapterNews extends FragmentStatePagerAdapter {

	public static final String URL = "URL";
	public static final String TITLE = "TITLE";
	
	public AdapterNews(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		String title;
		String url;
		switch (position) {
		case 0:
			title = "Dan Tri";
			url = "http://dantri.com.vn/cup-chau-au.rss";
			break;
		case 1:
			title = "VnExpress";
			url = "http://thethao.vnexpress.net/rss/tin-moi-nhat.rss";
			break;
		case 2:
			title = "24h";
			url = "http://dantri.com.vn/cup-chau-au.rss";
			break;
		case 3:
			title = "linkhay";
			url = "http://dantri.com.vn/cup-chau-au.rss";
			break;
		default:
			title = "Vietnamnet";
			url = "http://dantri.com.vn/cup-chau-au.rss";
			break;
		}
		Fragment fragment = new FragmentNews();
		Bundle args = new Bundle();
		args.putString(URL, url);
		args.putString(TITLE, title);
		
		fragment.setArguments(args);
		return fragment;
	}

	@Override
	public int getCount() {
		return 5;
	}

}
