package com.example.demofragment.network;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import com.example.demofragment.data.NewsItem;
import com.example.demofragment.parse.DanTriHandler;
import com.example.demofragment.parse.DataHandler;

public class ParseDanTriXMLTask extends
		AsyncTask<String, Integer, ArrayList<NewsItem>> {

	private static final String TAG = "TAG";
	private Matcher matcher;
	private Pattern pattern;

	@Override
	protected ArrayList<NewsItem> doInBackground(String... params) {
		String url = params[0];
		String content = getXMLFromUrl(url);
		return parseXMLToDanTriItem(content);
	}

	private String getXMLFromUrl(String url) {
		String xml = null;
		try {
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(url);

			HttpResponse httpResponse = httpClient.execute(httpPost);
			HttpEntity httpEntity = httpResponse.getEntity();
			xml = EntityUtils.toString(httpEntity);
			writeLog(xml);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// return XML
		return xml;
	}

	private void writeLog(String xml) throws IOException {
		String path = Environment.getExternalStorageDirectory()
				.getAbsolutePath();
		File file = new File(path + "/logxml.txt");
		file.createNewFile();

		FileWriter gpxwriter = new FileWriter(file);
		BufferedWriter out = new BufferedWriter(gpxwriter);
		out.write(xml);
		out.close();
		gpxwriter.close();
	}

	private ArrayList<NewsItem> parseXMLToDanTriItem(String content) {
		ArrayList<NewsItem> arrayList = new ArrayList<NewsItem>();

		try {
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp = spf.newSAXParser();

			XMLReader xr = sp.getXMLReader();

			DataHandler dataHandler = new DanTriHandler();
			xr.setContentHandler(dataHandler);

			String path = Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/logxml.txt";
			File file = new File(path);
			InputStream inputStream = new FileInputStream(file);
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");

			xr.parse(is);
			arrayList = dataHandler.getData();

		} catch (ParserConfigurationException pce) {
			Log.e("SAX XML", "sax parse error", pce);
		} catch (SAXException se) {
			Log.e("SAX XML", "sax error", se);
		} catch (IOException ioe) {
			Log.e("SAX XML", "sax parse io error", ioe);
		}
		return arrayList;
	}
}
