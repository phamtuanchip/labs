package com.example.demofragment.parse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VnExpressHandler extends DataHandler {

	@Override
	protected String getDesc(String content) {
		Pattern pattern = Pattern.compile("(<\\/br>.*)");
		Matcher matcher = pattern.matcher(content);
		int start = 0, end = 0;
		while (matcher.find()) {
			start = matcher.start() + 5;
			end = matcher.end();
			break;
		}
		String test = content.substring(start, end);
		return test;
	}

	protected String getUrlImage(String content) {
		Pattern pattern = Pattern.compile("(src=.*.jpg)");
		Matcher matcher = pattern.matcher(content);
		int start = 0, end = 0;
		while (matcher.find()) {
			start = matcher.start() + 5;
			end = matcher.end();
			break;
		}
		String test = content.substring(start, end);
		return test;
	};
}
