/** Automatically generated file. DO NOT MODIFY */
package com.example.demofragment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}