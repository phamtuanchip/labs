package com.example.demolocationandmap;

import com.google.android.maps.MapView;

import android.support.v4.app.Fragment;
public class FragmentMapView {
}
